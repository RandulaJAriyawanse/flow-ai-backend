from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from .utils import get_env

OPENAI_API_KEY=get_env('OPENAI_API_KEY')
OPENAI_MODEL=get_env('OPENAI_MODEL')
TEMPRATURE=get_env('TEMPERATURE')
MAX_TOKEN=get_env('MAX_TOKEN')
async def get_answer(question: str):
    prompt = ChatPromptTemplate.from_messages(
        [
            ("user", '{question}'),
        ]
    )
    model = ChatOpenAI(
        model=OPENAI_MODEL,
        api_key=OPENAI_API_KEY,
        temperature=TEMPRATURE,
        max_tokens=MAX_TOKEN,
        streaming=True
    )
    chain = prompt | model

    response = chain.astream({"question": question })
    async for chunk in response:
        content = chunk.content
        yield content