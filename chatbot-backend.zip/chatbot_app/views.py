from django.http import JsonResponse
from django.views import View
from django.utils.decorators import method_decorator
from django.http import StreamingHttpResponse

from .langchain_helper import get_answer
from django.views.decorators.csrf import csrf_exempt
import json


@method_decorator(csrf_exempt, name="dispatch")
class ChatBot(View):
    """
    Handle POST requests to generate an answer for a given input query.
    Methods:
    - post(request): Processes the input query and returns the generated response.
    """
    async def post(self, request) :
        try:
            data = json.loads(request.body)
            input_query = data.get("input_query", "")
            response = StreamingHttpResponse(get_answer(question=input_query))
            response["Content-Type"] = "text/plain"
            return response
        except json.JSONDecodeError:
            return JsonResponse({"errors": "Invlaid JSON"}, status=400)
