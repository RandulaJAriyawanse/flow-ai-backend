import os
import environ

def get_env(key:str) -> str:
    env = environ.Env(
    DEBUG=(bool, False)
    )
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    env_file_path = environ.Env.read_env(os.path.join(BASE_DIR, "chatbot_app", '.env'))
    return env(key)