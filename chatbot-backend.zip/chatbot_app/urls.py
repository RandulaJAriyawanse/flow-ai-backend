from django.contrib import admin
from django.urls import path

from .views import ChatBot

urlpatterns = [
    path('admin/', admin.site.urls),
    path('chatbot', ChatBot.as_view(), name="chatbot_view"),
]
